﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clock {

    public class ClockTime {

        public int Hour { get; set; }
        public int Minute { get; set; }
        public int Second { get; set; }

        public ClockTime(int hour = 0, int minute = 0, int second = 0) {
            this.Hour = hour;
            this.Minute = minute;
            this.Second = second;
        }

        public bool isValid() {
            return Hour > 0 && Minute >= 0 && Second >= 0
                && Hour < 24 && Minute < 60 && Second < 60;
        }

        public override bool Equals(object obj) {
            var time = obj as ClockTime;
            return time != null &&
                   Hour == time.Hour &&
                   Minute == time.Minute &&
                   Second == time.Second;
        }

        public override int GetHashCode() {
            var hashCode = 1505761165;
            hashCode = hashCode * -1521134295 + Hour.GetHashCode();
            hashCode = hashCode * -1521134295 + Minute.GetHashCode();
            hashCode = hashCode * -1521134295 + Second.GetHashCode();
            return hashCode;
        }
        public override string ToString() {
            return Hour + ":" + Minute + ":" + Second;
        }
    }
}
